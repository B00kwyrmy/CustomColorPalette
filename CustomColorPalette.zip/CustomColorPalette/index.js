import { AppRegistry, Image } from 'react-native';
import App from './src/App';
import { name as appName } from './app.json';
import { PluginManager } from 'sn-plugin-lib';

// ─── 1. Register component ────────────────────────────────────────────────────
AppRegistry.registerComponent(appName, () => App);

// ─── 2. Init SDK ──────────────────────────────────────────────────────────────
PluginManager.init();

// ─── 3. Pending button state ──────────────────────────────────────────────────
let _pendingButtonId = null;

PluginManager.registerButtonListener({
  onButtonPress: (event) => {
    _pendingButtonId = event.id;
  },
});

export function checkPendingButton() {
  const id = _pendingButtonId;
  _pendingButtonId = null;
  return id;
}

// ─── 4. Button registration ───────────────────────────────────────────────────

// Button 10: "Shades" — toolbar button, opens the shade picker UI.
PluginManager.registerButton(1, ['NOTE'], {
  id: 10,
  name: 'Shades',
  icon: Image.resolveAssetSource(require('./assets/icon.png')).uri,
  showType: 1,
});

// Button 20: "Reshade" — lasso toolbar, appears when content is lasso-selected.
PluginManager.registerButton(2, ['NOTE'], {
  id: 20,
  name: 'Reshade',
  icon: Image.resolveAssetSource(require('./assets/icon.png')).uri,
  showType: 1,
  editDataTypes: [0],
});
