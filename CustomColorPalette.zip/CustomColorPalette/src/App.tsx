import React, { useEffect, useState } from 'react';
import {
  DeviceEventEmitter,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { PluginCommAPI, PluginFileAPI, PluginManager, PluginNoteAPI } from 'sn-plugin-lib';
import { checkPendingButton } from '../index';

// ─── Color palettes ────────────────────────────────────────────────────────────
//
// penColor is a 32-bit signed int stored in the note file (Java writeInt).
// The built-in PDF renderer maps values 0-255 to grayscale ink density.
// Values outside 0-255 (i.e. full ARGB ints) are stored intact and readable
// by getElements / getLassoElements — the ExportColorPDF plugin reads them
// back and renders actual colors.  On screen and in the built-in PDF export
// these strokes render as a gray shade derived from the low byte.
//
// Format: (0xFF << 24) | (R << 16) | (G << 8) | B  — signed 32-bit.

interface ColorEntry {
  label:    string;
  penColor: number;   // signed 32-bit ARGB stored in stroke.penColor
  hex:      string;   // display hex for the swatch
}

function argb(hex: string): number {
  const c = hex.replace('#', '');
  const r = parseInt(c.slice(0,2), 16);
  const g = parseInt(c.slice(2,4), 16);
  const b = parseInt(c.slice(4,6), 16);
  return (0xff * 0x1000000 + r * 0x10000 + g * 0x100 + b) | 0;
}

// Pen colors — Ink Pen, Needle Point, Calligraphy
const PEN_COLORS: ColorEntry[] = [
  { label: 'Black',  hex: '#231F20', penColor: argb('#231F20') },
  { label: 'Blue',   hex: '#0033A0', penColor: argb('#0033A0') },
  { label: 'Red',    hex: '#BF062F', penColor: argb('#BF062F') },
  { label: 'Pink',   hex: '#CD6FBD', penColor: argb('#CD6FBD') },
  { label: 'Orange', hex: '#FF8200', penColor: argb('#FF8200') },
  { label: 'Green',  hex: '#007B5F', penColor: argb('#007B5F') },
  { label: 'Lime',   hex: '#00FF00', penColor: argb('#00FF00') },
  { label: 'Purple', hex: '#763AC7', penColor: argb('#763AC7') },
];

// Highlighter colors — marker / highlighter strokes
const HIGHLIGHT_COLORS: ColorEntry[] = [
  { label: 'Pink',   hex: '#F2C6DE', penColor: argb('#F2C6DE') },
  { label: 'Yellow', hex: '#FAEDCB', penColor: argb('#FAEDCB') },
  { label: 'Orange', hex: '#F7D9C4', penColor: argb('#F7D9C4') },
  { label: 'Blue',   hex: '#C6DEF1', penColor: argb('#C6DEF1') },
  { label: 'Green',  hex: '#C9E4DE', penColor: argb('#C9E4DE') },
  { label: 'Purple', hex: '#DBCDF0', penColor: argb('#DBCDF0') },
];

type TabKey = 'pen' | 'highlighter';

const TABS: { key: TabKey; label: string }[] = [
  { key: 'pen',         label: 'Pen' },
  { key: 'highlighter', label: 'Highlighter' },
];

const paletteForTab = (tab: TabKey): ColorEntry[] =>
  tab === 'highlighter' ? HIGHLIGHT_COLORS : PEN_COLORS;

type Mode = 'picker' | 'lasso';

// ─── Component ────────────────────────────────────────────────────────────────

export default function App(): React.JSX.Element {
  const [mode, setMode]           = useState<Mode>('picker');
  const [activeTab, setActiveTab] = useState<TabKey>('pen');
  const [selectedPen,  setSelectedPen]  = useState<ColorEntry>(PEN_COLORS[0]);
  const [selectedHigh, setSelectedHigh] = useState<ColorEntry>(HIGHLIGHT_COLORS[0]);
  const [status, setStatus] = useState('');
  const [busy,   setBusy]   = useState(false);

  useEffect(() => {
    const handleButton = (id: number | null) => {
      if (id === 20) {
        setMode('lasso');
        setStatus('Lasso-select content, choose a color, then tap Apply.');
      } else {
        setMode('picker');
        setStatus('Choose a color. Lasso content and tap Recolor to apply.');
      }
    };
    handleButton(checkPendingButton());
    const sub = DeviceEventEmitter.addListener('pluginButton', ({ id }: { id: number }) => {
      checkPendingButton(); handleButton(id);
    });
    return () => sub.remove();
  }, []);

  const selectedColor = activeTab === 'pen' ? selectedPen : selectedHigh;

  const selectColor = (c: ColorEntry) => {
    if (activeTab === 'pen') setSelectedPen(c); else setSelectedHigh(c);
    if (mode === 'picker')
      setStatus(`${TABS.find(t=>t.key===activeTab)?.label}: ${c.label} selected.`);
  };

  // ── Apply color to lasso selection ─────────────────────────────────────────
  // Stores the ARGB value in stroke.penColor (a 32-bit int field that persists
  // in the note file). The built-in PDF renders it as a gray shade; the
  // ExportColorPDF plugin reads it back as a full ARGB color.
  const applyLassoRecolor = async () => {
    setBusy(true); setStatus('Saving…');
    try {
      const saveResp = await PluginNoteAPI.saveCurrentNote();
      if (!saveResp.success) { setStatus(`Save failed: ${saveResp.error?.message}`); return; }

      const [fileResp, pageResp] = await Promise.all([
        PluginCommAPI.getCurrentFilePath(),
        PluginCommAPI.getCurrentPageNum(),
      ]);
      if (!fileResp.success || !pageResp.success) { setStatus('Could not read file/page.'); return; }

      const lassoResp = await PluginCommAPI.getLassoElements();
      if (!lassoResp.success || !lassoResp.result?.length) {
        setStatus('No lasso selection. Draw a lasso around content first.');
        return;
      }

      const elements = lassoResp.result as any[];
      const color    = selectedColor;
      const filePath = fileResp.result as string;
      const pageNum  = pageResp.result as number;

      const updates = elements.map((el: any) => {
        const upd: any = {
          type:      el.type,
          numInPage: el.numInPage,
          pageNum:   el.pageNum  ?? pageNum,
          layerNum:  el.layerNum ?? 0,
        };
        if (el.type === 0 && el.stroke) {
          upd.stroke = {
            penColor: color.penColor,   // ← full ARGB stored as 32-bit int
            penType:  el.stroke.penType ?? 1,
          };
        } else if (el.type === 700 && el.geometry) {
          upd.geometry = {
            type:     el.geometry.type     ?? 'GEO_polygon',
            penColor: color.penColor,
            penType:  el.geometry.penType  ?? 10,
            penWidth: el.geometry.penWidth ?? 100,
            points:   el.geometry.points   ?? [],
          };
        }
        return upd;
      });

      elements.forEach((el: any) => el.recycle?.());

      const modResp = await PluginFileAPI.modifyElements(filePath, pageNum, updates) as any;
      if (!modResp?.success) { setStatus(`Apply failed: ${modResp?.error?.message ?? 'unknown'}`); return; }

      await PluginNoteAPI.saveCurrentNote();
      await PluginCommAPI.reloadFile();

      const n = (modResp.result as number[] | null)?.length ?? updates.length;
      setStatus(`Applied ${color.label} to ${n} element(s).\nUse Export Color PDF to see full colors.`);
    } catch (err: any) {
      setStatus(`Error: ${err?.message ?? String(err)}`);
    } finally { setBusy(false); }
  };

  const close   = () => PluginManager.closePluginView();
  const palette = paletteForTab(activeTab);

  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Custom Color Palette</Text>
        <TouchableOpacity style={styles.closeBtn} onPress={close}>
          <Text style={styles.closeBtnText}>Close</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.banner}>
        <Text style={styles.bannerText}>
          {mode === 'lasso'
            ? 'Choose a color, tap Apply. Use Export Color PDF plugin for full-color output.'
            : 'Choose a color for Pen or Highlighter. Lasso content and tap Recolor to apply.'}
        </Text>
      </View>

      <View style={styles.tabRow}>
        {TABS.map(tab => (
          <TouchableOpacity key={tab.key}
            style={[styles.tab, activeTab === tab.key && styles.tabActive]}
            onPress={() => setActiveTab(tab.key)}>
            <Text style={[styles.tabText, activeTab === tab.key && styles.tabTextActive]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.list} contentContainerStyle={styles.listContent}>
        {palette.map(c => {
          const sel = selectedColor.penColor === c.penColor;
          return (
            <TouchableOpacity key={c.hex}
              style={[styles.row, sel && styles.rowSelected]}
              onPress={() => selectColor(c)} activeOpacity={0.7}>
              <View style={[styles.swatch, { backgroundColor: c.hex }]} />
              <View style={styles.info}>
                <Text style={styles.label}>{c.label}</Text>
                <Text style={styles.hex}>{c.hex}</Text>
              </View>
              {sel && <Text style={styles.check}>✓</Text>}
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {status !== '' && (
        <View style={styles.statusBar}>
          <Text style={styles.statusText}>{status}</Text>
        </View>
      )}

      {mode === 'lasso' && (
        <TouchableOpacity
          style={[styles.applyBtn, busy && styles.applyBtnDisabled]}
          onPress={applyLassoRecolor} disabled={busy}>
          <Text style={styles.applyBtnText}>
            {busy ? 'Applying…' : `Apply ${selectedColor.label} (${selectedColor.hex})`}
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root:            { flex: 1, backgroundColor: '#FFFFFF' },
  header:          { flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingHorizontal:20, paddingVertical:14, borderBottomWidth:1, borderBottomColor:'#000000' },
  headerTitle:     { fontSize:18, fontWeight:'bold', color:'#000000' },
  closeBtn:        { borderWidth:1, borderColor:'#000000', paddingHorizontal:16, paddingVertical:8 },
  closeBtnText:    { fontSize:14, color:'#000000' },
  banner:          { backgroundColor:'#F4F4F4', paddingHorizontal:20, paddingVertical:10, borderBottomWidth:1, borderBottomColor:'#DDDDDD' },
  bannerText:      { fontSize:12, color:'#333333', lineHeight:18 },
  tabRow:          { flexDirection:'row', borderBottomWidth:1, borderBottomColor:'#000000' },
  tab:             { flex:1, alignItems:'center', paddingVertical:14, borderRightWidth:1, borderRightColor:'#CCCCCC' },
  tabActive:       { backgroundColor:'#000000' },
  tabText:         { fontSize:15, color:'#000000', fontWeight:'500' },
  tabTextActive:   { color:'#FFFFFF', fontWeight:'bold' },
  list:            { flex:1 },
  listContent:     { paddingVertical:8 },
  row:             { flexDirection:'row', alignItems:'center', paddingHorizontal:20, paddingVertical:16, borderBottomWidth:1, borderBottomColor:'#EEEEEE' },
  rowSelected:     { backgroundColor:'#F0F0F0' },
  swatch:          { width:44, height:44, borderWidth:1, borderColor:'#999999', marginRight:18 },
  info:            { flex:1 },
  label:           { fontSize:18, fontWeight:'600', color:'#000000' },
  hex:             { fontSize:12, color:'#555555', marginTop:2 },
  check:           { fontSize:26, fontWeight:'bold', color:'#000000' },
  statusBar:       { paddingHorizontal:20, paddingVertical:10, borderTopWidth:1, borderTopColor:'#CCCCCC', backgroundColor:'#F8F8F8' },
  statusText:      { fontSize:12, color:'#333333' },
  applyBtn:        { backgroundColor:'#000000', marginHorizontal:20, marginVertical:14, paddingVertical:18, alignItems:'center' },
  applyBtnDisabled:{ backgroundColor:'#888888' },
  applyBtnText:    { color:'#FFFFFF', fontSize:16, fontWeight:'bold' },
});
