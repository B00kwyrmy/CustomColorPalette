#!/usr/bin/env bash
# Build CustomColorPalette.snplg
set -e

PLUGIN_KEY="CustomColorPalette"
OUT_DIR="build/outputs"
GEN_DIR="build/generated"

echo "Installing dependencies…"
npm install

echo "Bundling JavaScript…"
mkdir -p "$GEN_DIR" "$OUT_DIR"

npx react-native bundle \
  --platform android \
  --dev false \
  --entry-file index.js \
  --bundle-output "$GEN_DIR/${PLUGIN_KEY}.bundle" \
  --assets-dest "$GEN_DIR"

echo "Copying assets…"
cp PluginConfig.json "$GEN_DIR/"
# Update iconPath to the packaged absolute path
python3 -c "
import json, shutil, os
cfg = json.load(open('$GEN_DIR/PluginConfig.json'))
cfg['iconPath'] = '/icon.png'
json.dump(cfg, open('$GEN_DIR/PluginConfig.json', 'w'), indent=2)
"
cp assets/icon.png "$GEN_DIR/icon.png"

echo "Packaging .snplg…"
rm -f "$OUT_DIR/${PLUGIN_KEY}.snplg"
cd "$GEN_DIR"
zip -r "../../$OUT_DIR/${PLUGIN_KEY}.snplg" . -x "*.snplg" -x "*.zip"
cd ../..

echo "Done → $OUT_DIR/${PLUGIN_KEY}.snplg"
