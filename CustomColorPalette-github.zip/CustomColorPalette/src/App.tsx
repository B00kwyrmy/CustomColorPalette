import React, { useEffect, useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { PluginCommAPI, PluginFileAPI, PluginManager, PluginNoteAPI } from 'sn-plugin-lib';
import { checkPendingButton } from '../index';

// ─── Color palettes (alphabetical order) ────────────────────────────────────

interface ColorEntry {
  name: string;
  hex: string;
}

type TabKey = 'inkpen' | 'needlepoint' | 'shapes' | 'highlighter';

// Used for Ink Pen, Needle Point Pen, and Shapes tabs (alphabetical order)
const PEN_SHAPE_COLORS: ColorEntry[] = [
  { name: 'Black',  hex: '#231F20' },  // default
  { name: 'Blue',   hex: '#0033A0' },
  { name: 'Green',  hex: '#007B5F' },
  { name: 'Lime',   hex: '#00FF00' },
  { name: 'Orange', hex: '#FF8200' },
  { name: 'Pink',   hex: '#CD6FBD' },
  { name: 'Purple', hex: '#763AC7' },
  { name: 'Red',    hex: '#BF062F' },
];

const HIGHLIGHTER_COLORS: ColorEntry[] = [
  { name: 'Blue',   hex: '#008BD1' },
  { name: 'Gray',   hex: '#808080' },  // default
  { name: 'Green',  hex: '#00E240' },
  { name: 'Orange', hex: '#FFA442' },
  { name: 'Pink',   hex: '#FF4E8B' },
  { name: 'Purple', hex: '#9B3CA2' },
  { name: 'Yellow', hex: '#F6F000' },
];

// Default color pre-selected on open for each tab
const TAB_DEFAULTS: Record<TabKey, ColorEntry> = {
  inkpen:      { name: 'Black', hex: '#231F20' },
  needlepoint: { name: 'Black', hex: '#231F20' },
  shapes:      { name: 'Black', hex: '#231F20' },
  highlighter: { name: 'Gray',  hex: '#808080' },
};

const TABS: { key: TabKey; label: string }[] = [
  { key: 'inkpen',      label: 'Ink Pen' },
  { key: 'needlepoint', label: 'Needle Point' },
  { key: 'shapes',      label: 'Shapes' },
  { key: 'highlighter', label: 'Highlighter' },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

// Converts a 6-char hex color string to a signed 32-bit Android ARGB integer
function hexToArgbInt(hex: string): number {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return ((0xff << 24) | (r << 16) | (g << 8) | b) | 0;
}

function paletteForTab(tab: TabKey): ColorEntry[] {
  return tab === 'highlighter' ? HIGHLIGHTER_COLORS : PEN_SHAPE_COLORS;
}

// ─── Component ───────────────────────────────────────────────────────────────

export default function App(): React.JSX.Element {
  const [activeTab, setActiveTab] = useState<TabKey>('inkpen');
  // Each tab tracks its own selection; initialized to the per-tab default
  const [selectedColors, setSelectedColors] = useState<Record<TabKey, ColorEntry>>({ ...TAB_DEFAULTS });
  const [status, setStatus] = useState<string>('Tap a color, then tap "Apply to Selection".');
  const [busy, setBusy] = useState(false);

  // Consume the pending button press registered in index.js before App mounted
  useEffect(() => {
    checkPendingButton();
  }, []);

  const colors = paletteForTab(activeTab);
  const selectedColor = selectedColors[activeTab];

  const applyColor = async () => {
    setBusy(true);
    setStatus('Applying…');

    try {
      // Persist in-memory note state before modifying elements
      const saveResp = await PluginNoteAPI.saveCurrentNote();
      if (!saveResp.success) {
        setStatus(`Save failed: ${saveResp.error?.message ?? 'unknown error'}`);
        setBusy(false);
        return;
      }

      // Retrieve lasso-selected elements
      const lassoResp = await PluginCommAPI.getLassoElements();
      if (!lassoResp.success || !lassoResp.result || lassoResp.result.length === 0) {
        setStatus('No lasso selection found. Lasso-select content first.');
        setBusy(false);
        return;
      }

      const elements = lassoResp.result;
      const colorInt = hexToArgbInt(selectedColor.hex);

      // Apply the chosen color to every selected element
      elements.forEach((el: any) => {
        el.color = colorInt;
      });

      // Resolve current file and page
      const [fileResp, pageResp] = await Promise.all([
        PluginCommAPI.getCurrentFilePath(),
        PluginCommAPI.getCurrentPageNum(),
      ]);

      if (!fileResp.success || !pageResp.success) {
        elements.forEach((el: any) => el.recycle());
        setStatus('Could not read current file/page.');
        setBusy(false);
        return;
      }

      const filePath: string = fileResp.result;
      const pageNum: number = pageResp.result;

      const modifyResp = await PluginFileAPI.modifyElements(filePath, pageNum, elements);

      // Free native-side element memory
      elements.forEach((el: any) => el.recycle());

      if (!modifyResp.success) {
        setStatus(`Apply failed: ${modifyResp.error?.message ?? 'unknown error'}`);
        setBusy(false);
        return;
      }

      await PluginCommAPI.reloadCurrentPage();
      setStatus(`Applied ${selectedColor.name} (${selectedColor.hex}) to ${elements.length} element(s).`);
    } catch (err: any) {
      setStatus(`Error: ${err?.message ?? String(err)}`);
    } finally {
      setBusy(false);
    }
  };

  const close = () => PluginManager.closePluginView();

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Custom Color Palette</Text>
        <TouchableOpacity style={styles.closeBtn} onPress={close}>
          <Text style={styles.closeBtnText}>Close</Text>
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabRow}>
        {TABS.map(tab => (
          <TouchableOpacity
            key={tab.key}
            style={[styles.tab, activeTab === tab.key && styles.tabActive]}
            onPress={() => setActiveTab(tab.key)}
          >
            <Text style={[styles.tabText, activeTab === tab.key && styles.tabTextActive]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Color list */}
      <ScrollView style={styles.colorList} contentContainerStyle={styles.colorListContent}>
        {colors.map(color => {
          const isSelected = selectedColor?.hex === color.hex;
          return (
            <TouchableOpacity
              key={color.hex}
              style={[styles.colorRow, isSelected && styles.colorRowSelected]}
              onPress={() => setSelectedColors(prev => ({ ...prev, [activeTab]: color }))}
              activeOpacity={0.7}
            >
              {/* Swatch — on e-ink displays this appears as a shaded box */}
              <View style={[styles.swatch, { backgroundColor: color.hex }]} />
              <View style={styles.colorInfo}>
                <Text style={styles.colorName}>{color.name}</Text>
                <Text style={styles.colorHex}>{color.hex}</Text>
              </View>
              {isSelected && <Text style={styles.checkmark}>✓</Text>}
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Status */}
      <View style={styles.statusBar}>
        <Text style={styles.statusText}>{status}</Text>
      </View>

      {/* Apply button */}
      <TouchableOpacity
        style={[styles.applyBtn, busy && styles.applyBtnDisabled]}
        onPress={applyColor}
        disabled={busy}
      >
        <Text style={styles.applyBtnText}>
          {busy
            ? 'Applying…'
            : `Apply ${selectedColor.name} (${selectedColor.hex}) to Selection`}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000000',
  },
  closeBtn: {
    borderWidth: 1,
    borderColor: '#000000',
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  closeBtnText: {
    fontSize: 15,
    color: '#000000',
  },
  tabRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    borderRightWidth: 1,
    borderRightColor: '#000000',
  },
  tabActive: {
    backgroundColor: '#000000',
  },
  tabText: {
    fontSize: 13,
    color: '#000000',
  },
  tabTextActive: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  colorList: {
    flex: 1,
  },
  colorListContent: {
    paddingVertical: 8,
  },
  colorRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#CCCCCC',
  },
  colorRowSelected: {
    backgroundColor: '#EEEEEE',
  },
  swatch: {
    width: 36,
    height: 36,
    borderWidth: 1,
    borderColor: '#000000',
    marginRight: 16,
  },
  colorInfo: {
    flex: 1,
  },
  colorName: {
    fontSize: 17,
    fontWeight: '600',
    color: '#000000',
  },
  colorHex: {
    fontSize: 13,
    color: '#444444',
    marginTop: 2,
  },
  checkmark: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#000000',
  },
  statusBar: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: '#CCCCCC',
    backgroundColor: '#F8F8F8',
  },
  statusText: {
    fontSize: 13,
    color: '#333333',
  },
  applyBtn: {
    backgroundColor: '#000000',
    marginHorizontal: 20,
    marginVertical: 14,
    paddingVertical: 16,
    alignItems: 'center',
  },
  applyBtnDisabled: {
    backgroundColor: '#888888',
  },
  applyBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
